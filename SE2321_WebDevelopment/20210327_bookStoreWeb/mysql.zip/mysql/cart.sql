/*
-- Query: SELECT * FROM myBookStoreDataBase.cart
LIMIT 0, 1000

-- Date: 2021-07-04 14:25
*/
INSERT INTO `` (`cart_id`,`author`,`name`,`number`,`price`,`book_id`) VALUES (106,'Liu Cixion','Three Body',6,2340,1);
INSERT INTO `` (`cart_id`,`author`,`name`,`number`,`price`,`book_id`) VALUES (52,' Ashlee Vance','Elon Musk',1,3299,4);
