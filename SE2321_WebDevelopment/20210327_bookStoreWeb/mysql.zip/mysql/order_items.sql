/*
-- Query: SELECT * FROM myBookStoreDataBase.order_items
LIMIT 0, 1000

-- Date: 2021-07-04 14:25
*/
INSERT INTO `` (`item_id`,`book_id`,`book_num`,`order_id`) VALUES (1,1,34,1);
INSERT INTO `` (`item_id`,`book_id`,`book_num`,`order_id`) VALUES (2,2,45,1);
INSERT INTO `` (`item_id`,`book_id`,`book_num`,`order_id`) VALUES (3,1,2,2);
INSERT INTO `` (`item_id`,`book_id`,`book_num`,`order_id`) VALUES (4,4,2,3);
