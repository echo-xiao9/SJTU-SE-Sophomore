/*
-- Query: SELECT * FROM myBookStoreDataBase.orders
LIMIT 0, 1000

-- Date: 2021-07-04 14:25
*/
INSERT INTO `` (`order_id`,`order_price`,`user_id`,`date`,`year`,`month`,`day`) VALUES (1,0,0,'2021-04-05','2019','4','5');
INSERT INTO `` (`order_id`,`order_price`,`user_id`,`date`,`year`,`month`,`day`) VALUES (2,20000,1,'2021-05-04','2020','5','4');
INSERT INTO `` (`order_id`,`order_price`,`user_id`,`date`,`year`,`month`,`day`) VALUES (3,4599,1,'2021-06-13','2021','6','13');
