/*
-- Query: SELECT * FROM myBookStoreDataBase.user_auth
LIMIT 0, 1000

-- Date: 2021-07-04 14:26
*/
INSERT INTO `` (`user_id`,`user_type`,`username`,`password`) VALUES (404,1,'echo','password');
INSERT INTO `` (`user_id`,`user_type`,`username`,`password`) VALUES (405,0,'hacker','no');
INSERT INTO `` (`user_id`,`user_type`,`username`,`password`) VALUES (403,2,'admin','admin');
