/*
-- Query: SELECT * FROM myBookStoreDataBase.user
LIMIT 0, 1000

-- Date: 2021-07-04 14:26
*/
INSERT INTO `` (`user_id`,`name`,`nickname`,`tel`,`address`,`type`,`bought_num`) VALUES (453,'admin','adminn','13456198786','Beijing',2,NULL);
INSERT INTO `` (`user_id`,`name`,`nickname`,`tel`,`address`,`type`,`bought_num`) VALUES (454,'echo','avril','134567890','Ningbo',1,NULL);
INSERT INTO `` (`user_id`,`name`,`nickname`,`tel`,`address`,`type`,`bought_num`) VALUES (455,'hacker','ha','13968765456','Shanghai',0,NULL);
