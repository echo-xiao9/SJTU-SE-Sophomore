import './Carousel.css';

function Carousel() {
  return (
<div className="container" id="Carousel">
        <div className="carousel">
          <div className="carousel__face"><span></span></div>
          <div className="carousel__face"><span></span></div>
          <div className="carousel__face"><span></span></div>
          <div className="carousel__face"><span></span></div>
          <div className="carousel__face"><span></span></div>
          <div className="carousel__face"><span></span></div>
          {/* <div className="carousel__face"><span>And see</span></div> */}
          {/* <div className="carousel__face"><span>How IT Works</span></div>
          <div className="carousel__face"><span>Woow</span></div> */}
        </div>
      </div>
);
}

export default Carousel;