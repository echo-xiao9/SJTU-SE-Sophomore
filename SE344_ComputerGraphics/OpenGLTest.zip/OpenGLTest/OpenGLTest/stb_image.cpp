//
//  stb_image.cpp
//  OpenGLTest
//
//  Created by 康艺潇 on 2021/9/25.
//
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>
