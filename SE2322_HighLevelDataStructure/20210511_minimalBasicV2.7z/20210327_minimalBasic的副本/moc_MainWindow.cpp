/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MainWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[43];
    char stringdata0[429];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "codeLineEdit_return"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 8), // "clearAll"
QT_MOC_LITERAL(4, 41, 14), // "clearAppStatus"
QT_MOC_LITERAL(5, 56, 21), // "on_loadButton_clicked"
QT_MOC_LITERAL(6, 78, 8), // "loadStat"
QT_MOC_LITERAL(7, 87, 6), // "runApp"
QT_MOC_LITERAL(8, 94, 7), // "runStmt"
QT_MOC_LITERAL(9, 102, 29), // "map<int,Statement*>::iterator"
QT_MOC_LITERAL(10, 132, 30), // "map<int,Statement*>::iterator&"
QT_MOC_LITERAL(11, 163, 2), // "it"
QT_MOC_LITERAL(12, 166, 14), // "getCodeLineVal"
QT_MOC_LITERAL(13, 181, 17), // "getCodeLineStrVal"
QT_MOC_LITERAL(14, 199, 5), // "debug"
QT_MOC_LITERAL(15, 205, 6), // "stepIn"
QT_MOC_LITERAL(16, 212, 8), // "toNormal"
QT_MOC_LITERAL(17, 221, 10), // "parse_line"
QT_MOC_LITERAL(18, 232, 7), // "parse_t"
QT_MOC_LITERAL(19, 240, 8), // "QString&"
QT_MOC_LITERAL(20, 249, 4), // "line"
QT_MOC_LITERAL(21, 254, 10), // "parse_stmt"
QT_MOC_LITERAL(22, 265, 3), // "ptr"
QT_MOC_LITERAL(23, 269, 7), // "stmt_t&"
QT_MOC_LITERAL(24, 277, 4), // "stmt"
QT_MOC_LITERAL(25, 282, 9), // "parse_cmd"
QT_MOC_LITERAL(26, 292, 3), // "cmd"
QT_MOC_LITERAL(27, 296, 9), // "parse_num"
QT_MOC_LITERAL(28, 306, 4), // "int&"
QT_MOC_LITERAL(29, 311, 3), // "val"
QT_MOC_LITERAL(30, 315, 9), // "parse_var"
QT_MOC_LITERAL(31, 325, 4), // "name"
QT_MOC_LITERAL(32, 330, 9), // "parse_exp"
QT_MOC_LITERAL(33, 340, 3), // "exp"
QT_MOC_LITERAL(34, 344, 11), // "parse_delim"
QT_MOC_LITERAL(35, 356, 5), // "delim"
QT_MOC_LITERAL(36, 362, 12), // "parse_string"
QT_MOC_LITERAL(37, 375, 11), // "inputString"
QT_MOC_LITERAL(38, 387, 10), // "find_instr"
QT_MOC_LITERAL(39, 398, 7), // "stmt_t*"
QT_MOC_LITERAL(40, 406, 11), // "judge_infix"
QT_MOC_LITERAL(41, 418, 6), // "string"
QT_MOC_LITERAL(42, 425, 3) // "str"

    },
    "MainWindow\0codeLineEdit_return\0\0"
    "clearAll\0clearAppStatus\0on_loadButton_clicked\0"
    "loadStat\0runApp\0runStmt\0"
    "map<int,Statement*>::iterator\0"
    "map<int,Statement*>::iterator&\0it\0"
    "getCodeLineVal\0getCodeLineStrVal\0debug\0"
    "stepIn\0toNormal\0parse_line\0parse_t\0"
    "QString&\0line\0parse_stmt\0ptr\0stmt_t&\0"
    "stmt\0parse_cmd\0cmd\0parse_num\0int&\0val\0"
    "parse_var\0name\0parse_exp\0exp\0parse_delim\0"
    "delim\0parse_string\0inputString\0"
    "find_instr\0stmt_t*\0judge_infix\0string\0"
    "str"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    1,  130,    2, 0x08 /* Private */,
      12,    0,  133,    2, 0x08 /* Private */,
      13,    0,  134,    2, 0x08 /* Private */,
      14,    0,  135,    2, 0x08 /* Private */,
      15,    0,  136,    2, 0x08 /* Private */,
      16,    0,  137,    2, 0x08 /* Private */,
      17,    1,  138,    2, 0x08 /* Private */,
      21,    2,  141,    2, 0x08 /* Private */,
      25,    2,  146,    2, 0x08 /* Private */,
      27,    2,  151,    2, 0x08 /* Private */,
      30,    2,  156,    2, 0x08 /* Private */,
      32,    2,  161,    2, 0x08 /* Private */,
      34,    2,  166,    2, 0x08 /* Private */,
      36,    2,  171,    2, 0x08 /* Private */,
      38,    1,  176,    2, 0x08 /* Private */,
      40,    1,  179,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 9, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 18, 0x80000000 | 19,   20,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 23,   22,   24,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 23,   22,   26,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 28,   22,   29,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 19,   22,   31,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 19,   22,   33,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 19,   22,   35,
    0x80000000 | 18, 0x80000000 | 19, 0x80000000 | 19,   22,   37,
    0x80000000 | 39, QMetaType::QString,   31,
    QMetaType::Bool, 0x80000000 | 41,   42,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->codeLineEdit_return(); break;
        case 1: _t->clearAll(); break;
        case 2: _t->clearAppStatus(); break;
        case 3: _t->on_loadButton_clicked(); break;
        case 4: _t->loadStat(); break;
        case 5: _t->runApp(); break;
        case 6: { map<int,Statement*>::iterator _r = _t->runStmt((*reinterpret_cast< map<int,Statement*>::iterator(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< map<int,Statement*>::iterator*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->getCodeLineVal(); break;
        case 8: _t->getCodeLineStrVal(); break;
        case 9: _t->debug(); break;
        case 10: _t->stepIn(); break;
        case 11: _t->toNormal(); break;
        case 12: { parse_t _r = _t->parse_line((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 13: { parse_t _r = _t->parse_stmt((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< stmt_t(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 14: { parse_t _r = _t->parse_cmd((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< stmt_t(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 15: { parse_t _r = _t->parse_num((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 16: { parse_t _r = _t->parse_var((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 17: { parse_t _r = _t->parse_exp((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 18: { parse_t _r = _t->parse_delim((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 19: { parse_t _r = _t->parse_string((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< parse_t*>(_a[0]) = std::move(_r); }  break;
        case 20: { stmt_t* _r = _t->find_instr((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< stmt_t**>(_a[0]) = std::move(_r); }  break;
        case 21: { bool _r = _t->judge_infix((*reinterpret_cast< string(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
