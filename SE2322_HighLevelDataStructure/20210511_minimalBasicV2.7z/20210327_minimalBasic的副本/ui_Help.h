/********************************************************************************
** Form generated from reading UI file 'Help.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELP_H
#define UI_HELP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Help
{
public:
    QVBoxLayout *verticalLayout_10;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_12;
    QLabel *label_2;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_13;
    QLabel *label_14;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_18;
    QLabel *label_15;
    QLabel *label_17;
    QLabel *label_16;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_30;
    QLabel *label_31;
    QLabel *label_29;
    QVBoxLayout *verticalLayout_9;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_3;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_32;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_33;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_23;
    QLabel *label_24;

    void setupUi(QWidget *Help)
    {
        if (Help->objectName().isEmpty())
            Help->setObjectName(QString::fromUtf8("Help"));
        Help->resize(843, 586);
        verticalLayout_10 = new QVBoxLayout(Help);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        label = new QLabel(Help);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_10->addWidget(label);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_12 = new QLabel(Help);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_2->addWidget(label_12);

        label_2 = new QLabel(Help);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_4 = new QLabel(Help);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(Help);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(Help);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(Help);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(Help);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout->addWidget(label_8);

        label_9 = new QLabel(Help);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout->addWidget(label_9);

        label_10 = new QLabel(Help);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout->addWidget(label_10);


        verticalLayout_2->addLayout(verticalLayout);

        label_11 = new QLabel(Help);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_2->addWidget(label_11);

        label_13 = new QLabel(Help);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout_2->addWidget(label_13);

        label_14 = new QLabel(Help);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout_2->addWidget(label_14);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_18 = new QLabel(Help);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout_3->addWidget(label_18);

        label_15 = new QLabel(Help);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout_3->addWidget(label_15);

        label_17 = new QLabel(Help);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_3->addWidget(label_17);

        label_16 = new QLabel(Help);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_3->addWidget(label_16);

        label_19 = new QLabel(Help);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        verticalLayout_3->addWidget(label_19);

        label_20 = new QLabel(Help);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        verticalLayout_3->addWidget(label_20);


        verticalLayout_2->addLayout(verticalLayout_3);


        horizontalLayout_2->addLayout(verticalLayout_2);

        label_30 = new QLabel(Help);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        horizontalLayout_2->addWidget(label_30);

        label_31 = new QLabel(Help);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        horizontalLayout_2->addWidget(label_31);

        label_29 = new QLabel(Help);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        horizontalLayout_2->addWidget(label_29);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_21 = new QLabel(Help);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        verticalLayout_5->addWidget(label_21);

        label_22 = new QLabel(Help);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        verticalLayout_5->addWidget(label_22);

        label_3 = new QLabel(Help);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_5->addWidget(label_3);


        verticalLayout_9->addLayout(verticalLayout_5);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        label_27 = new QLabel(Help);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        verticalLayout_8->addWidget(label_27);

        label_28 = new QLabel(Help);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        verticalLayout_8->addWidget(label_28);

        label_32 = new QLabel(Help);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        verticalLayout_8->addWidget(label_32);


        verticalLayout_9->addLayout(verticalLayout_8);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_25 = new QLabel(Help);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        verticalLayout_7->addWidget(label_25);

        label_26 = new QLabel(Help);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        verticalLayout_7->addWidget(label_26);

        label_33 = new QLabel(Help);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        verticalLayout_7->addWidget(label_33);


        verticalLayout_9->addLayout(verticalLayout_7);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_23 = new QLabel(Help);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        verticalLayout_6->addWidget(label_23);

        label_24 = new QLabel(Help);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        verticalLayout_6->addWidget(label_24);


        verticalLayout_9->addLayout(verticalLayout_6);


        horizontalLayout_2->addLayout(verticalLayout_9);


        verticalLayout_10->addLayout(horizontalLayout_2);


        retranslateUi(Help);

        QMetaObject::connectSlotsByName(Help);
    } // setupUi

    void retranslateUi(QWidget *Help)
    {
        Help->setWindowTitle(QApplication::translate("Help", "Form", nullptr));
        label->setText(QApplication::translate("Help", "                                                                                                        HELP \345\270\256\345\212\251\346\226\207\346\241\243", nullptr));
        label_12->setText(QApplication::translate("Help", "\345\221\275\344\273\244\350\276\223\345\205\245\347\252\227\345\217\243", nullptr));
        label_2->setText(QApplication::translate("Help", "1. \345\270\246\350\241\214\345\217\267\347\232\204\345\243\260\346\230\216\357\274\210Statement\357\274\211\357\274\214\346\214\211\344\270\213\345\233\236\350\275\246\351\224\256\350\207\252\345\212\250\346\240\274\345\274\217\345\214\226\345\271\266\346\230\276\347\244\272\345\234\250\344\273\243\347\240\201\346\241\206\345\206\205", nullptr));
        label_4->setText(QApplication::translate("Help", "REM  XXX                           \346\263\250\351\207\212", nullptr));
        label_5->setText(QApplication::translate("Help", "LET   var = exp                   \350\265\213\345\200\274", nullptr));
        label_6->setText(QApplication::translate("Help", "PRINT exp                          \346\211\223\345\215\260", nullptr));
        label_7->setText(QApplication::translate("Help", "INPUT   var                         \350\276\223\345\205\245\345\217\230\351\207\217\344\277\241\346\201\257", nullptr));
        label_8->setText(QApplication::translate("Help", "GOTO   n                             \345\211\215\345\276\200\345\257\271\345\272\224\350\241\214", nullptr));
        label_9->setText(QApplication::translate("Help", "IF exp1 op exp2 THEN n   \346\235\241\344\273\266\346\210\220\347\253\213\350\267\263\350\275\254\345\210\260\347\254\254n\350\241\214\346\211\247\350\241\214\357\274\214\345\205\266\344\270\255 op\345\214\205\346\213\254 < > =", nullptr));
        label_10->setText(QApplication::translate("Help", "END                                     \347\250\213\345\272\217\347\273\223\346\235\237", nullptr));
        label_11->setText(QApplication::translate("Help", "2. \344\270\215\345\270\246\350\241\214\345\217\267\347\232\204\345\243\260\346\230\216\357\274\210Statement\357\274\211", nullptr));
        label_13->setText(QApplication::translate("Help", "LET\343\200\201PRINT\343\200\201INPUT\345\217\257\344\273\245\344\270\215\345\270\246\350\241\214\345\217\267\347\233\264\346\216\245\350\276\223\345\205\245\346\211\247\350\241\214", nullptr));
        label_14->setText(QApplication::translate("Help", "3. \344\270\215\345\270\246\350\241\214\345\217\267\347\232\204\345\221\275\344\273\244", nullptr));
        label_18->setText(QApplication::translate("Help", "CLEAR\357\274\232 \346\270\205\347\251\272\346\225\264\344\270\252\347\250\213\345\272\217", nullptr));
        label_15->setText(QApplication::translate("Help", "RUN:        \351\241\272\345\272\217\346\211\247\350\241\214", nullptr));
        label_17->setText(QApplication::translate("Help", "LIST:        \345\210\227\345\207\272\346\211\247\350\241\214\346\255\245\351\252\244", nullptr));
        label_16->setText(QApplication::translate("Help", "LOAD:     \345\212\240\350\275\275\346\226\207\344\273\266", nullptr));
        label_19->setText(QApplication::translate("Help", "HELP\357\274\232   \345\261\225\347\244\272\345\270\256\345\212\251\346\226\207\346\241\243\347\252\227\345\217\243", nullptr));
        label_20->setText(QApplication::translate("Help", "QUIT\357\274\232    \351\200\200\345\207\272\347\250\213\345\272\217", nullptr));
        label_30->setText(QString());
        label_31->setText(QString());
        label_29->setText(QString());
        label_21->setText(QApplication::translate("Help", "\344\273\243\347\240\201\345\214\272", nullptr));
        label_22->setText(QApplication::translate("Help", "\351\200\232\350\277\207\346\226\207\344\273\266\346\210\226\350\200\205\351\200\220\350\241\214\350\276\223\345\205\245\345\276\227\345\210\260\347\232\204\346\240\274\345\274\217\345\214\226\347\232\204\346\214\211\345\272\217\345\217\267\346\216\222\345\210\227\344\273\243\347\240\201", nullptr));
        label_3->setText(QApplication::translate("Help", "------------------------------------------------------------", nullptr));
        label_27->setText(QApplication::translate("Help", "\346\217\220\347\244\272\344\277\241\346\201\257", nullptr));
        label_28->setText(QApplication::translate("Help", "\346\230\276\347\244\272\345\220\204\347\261\273\351\224\231\350\257\257\346\217\220\347\244\272\345\222\214\347\250\213\345\272\217\350\277\220\350\241\214\346\210\220\345\212\237\346\217\220\347\244\272", nullptr));
        label_32->setText(QApplication::translate("Help", "------------------------------------------------------------", nullptr));
        label_25->setText(QApplication::translate("Help", "\345\217\245\346\263\225\344\270\216\350\257\255\346\263\225\346\240\221", nullptr));
        label_26->setText(QApplication::translate("Help", "\346\214\211\347\205\247\345\211\215\347\275\256\350\241\250\350\276\276\345\274\217\357\274\214\351\200\222\345\275\222\345\261\225\347\244\272\346\257\217\344\270\200\350\241\214\344\273\243\347\240\201\347\232\204\345\217\245\346\263\225\347\273\223\346\236\204", nullptr));
        label_33->setText(QApplication::translate("Help", "------------------------------------------------------------", nullptr));
        label_23->setText(QApplication::translate("Help", "\345\217\230\351\207\217\344\277\241\346\201\257", nullptr));
        label_24->setText(QApplication::translate("Help", "\346\211\247\350\241\214\344\273\243\347\240\201\345\220\216\357\274\210run\357\274\211\357\274\214\345\261\225\347\244\272\347\250\213\345\272\217\344\270\255\345\217\230\351\207\217\347\232\204\346\234\200\347\273\210\345\200\274", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Help: public Ui_Help {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELP_H
